package com.example.basketballscore

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.basketballscore.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private fun openrestartactivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)

        val Toast = Toast.makeText(
            applicationContext,
            "Se ha reiniciado en ceros el marcador",
            Toast.LENGTH_LONG
        )
        Toast.setGravity(Gravity.LEFT,100,100)
        Toast.show()
    }
    private fun openDetailActivity(scoreuno: String, scoredos: String){
        val intent = Intent( this, DetailActivity::class.java)
        intent.putExtra("score_uno", scoreuno)
        intent.putExtra("score_dos", scoredos)
        startActivity(intent)

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.detalles.setOnClickListener{
           val scoreuno = binding.scoreUno.text.toString()
            val scoredos = binding.scoreDos.text.toString()
            openDetailActivity(scoreuno, scoredos)
        }

        val textScoreLocal = findViewById<TextView>(R.id.scoreUno)
        val textScoreVisitante = findViewById<TextView>(R.id.scoreDos)
        var scoreLocal = 0
        var scoreVisitante = 0

        textScoreLocal.text = scoreLocal.toString()
        textScoreVisitante.text = scoreVisitante.toString()
        /*acciones de los 3 botones local*/
        val unoSumaLocal = findViewById<Button>(R.id.unoSumaLocal)

        unoSumaLocal.setOnClickListener{
            scoreLocal += 1
            textScoreLocal.text = scoreLocal.toString()
        }
        val dosSumaLocal = findViewById<Button>(R.id.dosSumaLocal)
        dosSumaLocal.setOnClickListener{
            scoreLocal = scoreLocal+2
            textScoreLocal.text = scoreLocal.toString()
        }
        val unoSumaVisitante = findViewById<Button>(R.id.unoSumaVisitante)

        unoSumaVisitante.setOnClickListener{
            scoreVisitante += 1
            textScoreVisitante.text = scoreVisitante.toString()
        }
        val dosSumaVisitante = findViewById<Button>(R.id.dosSumaVisitante)
        dosSumaVisitante.setOnClickListener{
            scoreVisitante = scoreVisitante+2
            textScoreVisitante.text = scoreVisitante.toString()
        }

        val restaLocal = findViewById<Button>(R.id.menosLocal)
        restaLocal.setOnClickListener {

            if (scoreLocal <= 0) {
                val Toast = Toast.makeText(
                    applicationContext,
                    "No puedes tener un puntaje menor a cero en el marcador",
                    Toast.LENGTH_SHORT
                )
                Toast.setGravity(Gravity.LEFT, 100, -500)
                Toast.show()
            } else {
                scoreLocal = scoreLocal - 1
                textScoreLocal.text = scoreLocal.toString()
            }
        }

            val restaVisitante = findViewById<Button>(R.id.menosVisitante)
            restaVisitante.setOnClickListener{

            if (scoreVisitante <= 0)
            {
                val Toast = Toast.makeText(
                    applicationContext,
                    "No puedes tener un puntaje menor a cero en el marcador",
                    Toast.LENGTH_SHORT
                )
                Toast.setGravity(Gravity.LEFT, 100, -500)
                Toast.show()
            }
            else{
                scoreVisitante = scoreVisitante-1
                textScoreVisitante.text = scoreVisitante.toString()
            }
        }

        /* Botón de Reset */
        val restart = findViewById<Button>(R.id.restart)
        restart.setOnClickListener{

            openrestartactivity()
        }


    }
}